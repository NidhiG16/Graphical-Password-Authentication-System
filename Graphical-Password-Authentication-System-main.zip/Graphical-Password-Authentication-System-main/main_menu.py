from tkinter import *
from tkinter import font
import custom_button
import segments
import email_ver
#import grid

def load_email_ver(window, menu_frame):
    win.destroy()
    email_ver.start()
    
#def load_segmented(window, menu_frame):
    #menu_frame.pack_forget()
    #segments.start(window)

def start(win):
    win.geometry("600x600")
    win.title("Graphical Password Authentication System")
   
    menu_frame = Frame(win, height=600, width=1280, bg = "white")
    menu_frame.pack(fill='both', expand=1)

    label = Label(menu_frame, text="Graphical Password Authentication System", font=('Freestyle Script', 35))
    label.pack(padx=40, pady=30)

    btn_height = 100
    btn_width = 450
    btn_font = ('Trebuchet MS', 20)

    #btn2 = custom_button.TkinterCustomButton(master=menu_frame, text="Test Segmented Images", text_font=btn_font,
                                             #height=btn_height, width=btn_width, corner_radius=10,
                                             #command=lambda: load_segmented(win, menu_frame)).place(relx=0.5,
                                                                                                    #rely=0.5,#position of button


##    custom_button.TkinterCustomButton(master=menu_frame, text="Login", height=btn_height, corner_radius=10,
##                                      command=lambda: load_email_ver(win, menu_frame)).place(relx=0.5, rely=0.5,
##                                                                                              anchor=CENTER)
##                                                                                                    #anchor=CENTER)
##

    btn1 = custom_button.TkinterCustomButton(master=menu_frame, text="Login", text_font=50,
                                             height=40, width=70, corner_radius=10,
                                             command=lambda: load_email_ver(win, menu_frame)).place(relx=0.5,
                                                                                                    rely=0.5,#position of button
                                                                                                    anchor=CENTER)
##
##   



    win.mainloop()



if __name__ == "__main__":
    win = Tk()
    start(win)
